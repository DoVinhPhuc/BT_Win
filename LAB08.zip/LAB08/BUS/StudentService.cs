﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DAL.Model;

namespace BUS
{
    public class StudentService
    {
        private Model1 context;

        public StudentService()
        {
            context = new Model1();
        }

        // Lấy tất cả sinh viên
        public List<Sinhvien> GetAllStudents()
        {
            return context.Sinhvien.Include("Lop").ToList();
        }

        // Lấy tất cả lớp
        public List<Lop> GetAllClasses()
        {
            return context.Lop.ToList();
        }

        // Thêm sinh viên mới
        public void AddStudent(Sinhvien student)
        {
            context.Sinhvien.Add(student);
            context.SaveChanges();
        }

        // Sửa thông tin sinh viên
        public void UpdateStudent(Sinhvien student)
        {
            var existingStudent = context.Sinhvien.FirstOrDefault(s => s.MaSV == student.MaSV);
            if (existingStudent != null)
            {
                existingStudent.HotenSV = student.HotenSV;
                existingStudent.NgaySinh = student.NgaySinh;
                existingStudent.MaLop = student.MaLop;
                context.SaveChanges();
            }
        }

        // Xóa sinh viên
        public void DeleteStudent(string maSV)
        {
            var student = context.Sinhvien.FirstOrDefault(s => s.MaSV == maSV);
            if (student != null)
            {
                context.Sinhvien.Remove(student);
                context.SaveChanges();
            }
        }
        public List<Sinhvien> SearchStudentByName(string keyword)
        {
            using (var context = new Model1())
            {
                // Chuyển cả từ khóa và giá trị cột trong cơ sở dữ liệu thành chữ thường
                return context.Sinhvien
                              .Include("Lop") // Bao gồm thông tin lớp
                              .Where(s => s.HotenSV.ToLower().Contains(keyword.ToLower()) // Tìm theo tên
                                       || s.MaSV.ToLower().Contains(keyword.ToLower())) // Tìm theo mã sinh viên
                              .ToList();
            }
        }

       
    }
}

