﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using BUS;
using DAL.Model;

namespace GUI
{
    public partial class frmSinhVien : Form
    {
        private StudentService studentService; // Khởi tạo tầng BUS
        private bool isEditing = false; // Biến kiểm tra trạng thái chỉnh sửa
        public frmSinhVien()
        {
            InitializeComponent();
            studentService = new StudentService();

        }

        private void txtMaSV_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtHotenSV_TextChanged(object sender, EventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {
            LoadStudentList();
            LoadClassList();
            ResetForm();
        }
        // Load danh sách sinh viên lên ListView
        private void LoadStudentList()
        {
            dgvSinhvien.Rows.Clear(); // Xóa tất cả các dòng trong DataGridView
            var students = studentService.GetAllStudents(); // Lấy danh sách sinh viên từ BUS

            foreach (var student in students)
            {
                int rowIndex = dgvSinhvien.Rows.Add(); // Thêm một dòng mới vào DataGridView
                DataGridViewRow row = dgvSinhvien.Rows[rowIndex]; // Lấy dòng vừa thêm

                row.Cells[0].Value = student.MaSV; // Mã sinh viên
                row.Cells[1].Value = student.HotenSV; // Họ tên sinh viên
                row.Cells[2].Value = student.NgaySinh.ToString("dd/MM/yyyy"); // Ngày sinh
                row.Cells[3].Value = student.Lop.TenLop; // Tên lớp
            }
        }
        // Load danh sách lớp lên ComboBox
        private void LoadClassList()
        {
            var classes = studentService.GetAllClasses();
            cboLop.DataSource = classes;
            cboLop.DisplayMember = "TenLop";
            cboLop.ValueMember = "MaLop";
        }
        private void ResetForm()
        {
            txtMaSV.Clear();
            txtHotenSV.Clear();
            dtNgaysinh.Value = DateTime.Now;
            cboLop.SelectedIndex = -1;
            txtMaSV.Enabled = true;
            isEditing = false;
        }
        private void dtNgaysinh_ValueChanged(object sender, EventArgs e)
        {

        }

        private void cboLop_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void btTim_Click(object sender, EventArgs e)
        {
            string keyword = txtHotenSV.Text.Trim(); // Trim loại bỏ khoảng trắng ở đầu và cuối
            if (string.IsNullOrEmpty(keyword))
            {
                MessageBox.Show("Vui lòng nhập tên hoặc mã sinh viên để tìm kiếm!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            // Gọi phương thức tìm kiếm trong lớp StudentService
            var students = studentService.SearchStudentByName(keyword);

            // Xóa dữ liệu hiện tại trong DataGridView
            dgvSinhvien.Rows.Clear();

            // Thêm dữ liệu tìm kiếm vào DataGridView
            foreach (var student in students)
            {
                dgvSinhvien.Rows.Add(
                    student.MaSV,
                    student.HotenSV,
                    student.NgaySinh.ToString("dd/MM/yyyy"),
                    student.Lop.TenLop
                );
            }

            // Hiển thị thông báo nếu không tìm thấy sinh viên nào
            if (students.Count == 0)
            {
                MessageBox.Show("Không tìm thấy sinh viên nào!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }
        private void dgvSinhvien_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvSinhvien.SelectedRows.Count > 0)
            {
                var row = dgvSinhvien.SelectedRows[0]; // Lấy hàng được chọn

                txtMaSV.Text = row.Cells[0].Value.ToString(); // Mã SV
                txtHotenSV.Text = row.Cells[1].Value.ToString(); // Họ tên SV
                dtNgaysinh.Value = DateTime.Parse(row.Cells[2].Value.ToString()); // Ngày sinh
                cboLop.Text = row.Cells[3].Value.ToString(); // Tên lớp

                txtMaSV.Enabled = false; // Không cho phép chỉnh sửa mã sinh viên
                isEditing = true; // Đánh dấu trạng thái đang chỉnh sửa
            }
        }

        private void btThem_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                var student = new Sinhvien
                {
                    MaSV = txtMaSV.Text,
                    HotenSV = txtHotenSV.Text,
                    NgaySinh = dtNgaysinh.Value,
                    MaLop = cboLop.SelectedValue.ToString()
                };
                studentService.AddStudent(student);
                LoadStudentList();
                ResetForm();
                MessageBox.Show("Thêm sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btSua_Click(object sender, EventArgs e)
        {
            if (ValidateInput())
            {
                var student = new Sinhvien
                {
                    MaSV = txtMaSV.Text,
                    HotenSV = txtHotenSV.Text,
                    NgaySinh = dtNgaysinh.Value,
                    MaLop = cboLop.SelectedValue.ToString()
                };
                studentService.UpdateStudent(student);
                LoadStudentList();
                ResetForm();
                MessageBox.Show("Cập nhật thông tin sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void btXoa_Click(object sender, EventArgs e)
        {
            if (!string.IsNullOrEmpty(txtMaSV.Text))
            {
                var confirmResult = MessageBox.Show("Bạn có chắc chắn muốn xóa sinh viên này?", "Xác nhận", MessageBoxButtons.YesNo, MessageBoxIcon.Warning);
                if (confirmResult == DialogResult.Yes)
                {
                    studentService.DeleteStudent(txtMaSV.Text);
                    LoadStudentList();
                    ResetForm();
                    MessageBox.Show("Xóa sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
            else
            {
                MessageBox.Show("Vui lòng chọn sinh viên để xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
        }

        private void btLuu_Click(object sender, EventArgs e)
        {

        }

        private void btKhong_Click(object sender, EventArgs e)
        {
            ResetForm();
        }

        private void btThoat_Click(object sender, EventArgs e)
        {
            Close();
        }
        private bool ValidateInput()
        {
            if (string.IsNullOrEmpty(txtMaSV.Text) || string.IsNullOrEmpty(txtHotenSV.Text) || cboLop.SelectedIndex == -1)
            {
                MessageBox.Show("Vui lòng nhập đầy đủ thông tin!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
    }
}
