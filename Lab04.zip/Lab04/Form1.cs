﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Lab04.Models;

namespace Lab04
{
    public partial class frmQuanLySV : Form
    {
        public frmQuanLySV()
        {
            InitializeComponent();
        }

        private void frmQuanLySV_Load(object sender, EventArgs e)
        {
            try
            {
                StudentContextDB context = new StudentContextDB();
                List<Facullty> listFalcultys = context.Facullties.ToList(); // Lấy các khoa
                List<Student> listStudent = context.Students.ToList(); // Lấy danh sách sinh viên

                FillFalcultyCombobox(listFalcultys); // Binding dữ liệu vào combobox
                BindGrid(listStudent);              // Binding dữ liệu vào DataGridView
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Lỗi khi tải dữ liệu", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        //Hàm binding list có tên hiện thị là tên khoa, giá trị là Mã khoa
        private void FillFalcultyCombobox(List<Facullty> listFalcultys)
        {
            this.cmbKhoa.DataSource = listFalcultys;
            this.cmbKhoa.DisplayMember = "FacultyName";
            this.cmbKhoa.ValueMember = "FacultyID";
        }
        //Hàm binding gridView từ list sinh viên
        private bool ValidateInputs()
        {
            if (string.IsNullOrWhiteSpace(txtMaSoSV.Text) || txtMaSoSV.Text.Length != 10)
            {
                MessageBox.Show("Mã số sinh viên phải có đúng 10 ký tự!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtHoTen.Text))
            {
                MessageBox.Show("Vui lòng nhập họ tên sinh viên!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            if (string.IsNullOrWhiteSpace(txtDiemTB.Text) || !double.TryParse(txtDiemTB.Text, out _))
            {
                MessageBox.Show("Vui lòng nhập điểm trung bình hợp lệ!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return false;
            }
            return true;
        }
        private void BindGrid(List<Student> listStudent)
        {
            dgvStudent.Rows.Clear();
            foreach (var item in listStudent)
            {
                int index = dgvStudent.Rows.Add();
                dgvStudent.Rows[index].Cells[0].Value = item.StudentID;
                dgvStudent.Rows[index].Cells[1].Value = item.FullName;
                dgvStudent.Rows[index].Cells[2].Value = item.Facullty.FacultyName;
                dgvStudent.Rows[index].Cells[3].Value = item.AverageScore;
            }
        }

        private void btnThem_Click(object sender, EventArgs e)
        {

            try
            {
                if (!ValidateInputs()) return; // Kiểm tra thông tin đầu vào

                StudentContextDB context = new StudentContextDB();

                if (context.Students.Any(s => s.StudentID == txtMaSoSV.Text))
                {
                    MessageBox.Show("Mã SV đã tồn tại. Vui lòng nhập một mã khác.", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    return;
                }

                var newStudent = new Student
                {
                    StudentID = txtMaSoSV.Text,
                    FullName = txtHoTen.Text,
                    AverageScore = double.Parse(txtDiemTB.Text),
                    FacultyID = int.Parse(cmbKhoa.SelectedValue.ToString())
                };

                context.Students.Add(newStudent);
                context.SaveChanges();

                BindGrid(context.Students.ToList()); // Load lại danh sách
                ResetForm(); // Reset form về giá trị ban đầu

                MessageBox.Show("Thêm mới dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi thêm dữ liệu: {ex.Message}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }
        private void ResetForm()
        {
            txtMaSoSV.Clear();
            txtHoTen.Clear();
            txtDiemTB.Clear();
            cmbKhoa.SelectedIndex = -1;
        }


        private void btnSua_Click(object sender, EventArgs e)
        {
            {
                try
                {
                    if (!ValidateInputs()) return; // Kiểm tra thông tin đầu vào

                    StudentContextDB context = new StudentContextDB();

                    var student = context.Students.FirstOrDefault(s => s.StudentID == txtMaSoSV.Text);
                    if (student != null)
                    {
                        student.FullName = txtHoTen.Text;
                        student.AverageScore = double.Parse(txtDiemTB.Text);
                        student.FacultyID = int.Parse(cmbKhoa.SelectedValue.ToString());

                        context.SaveChanges();

                        BindGrid(context.Students.ToList()); // Load lại danh sách
                        ResetForm(); // Reset form về giá trị ban đầu

                        MessageBox.Show("Cập nhật dữ liệu thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                    else
                    {
                        MessageBox.Show("Không tìm thấy MSSV cần sửa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show($"Lỗi khi sửa dữ liệu: {ex.Message}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

        private void btnXoa_Click(object sender, EventArgs e)
        {
            try
            {
                StudentContextDB context = new StudentContextDB();

                var student = context.Students.FirstOrDefault(s => s.StudentID == txtMaSoSV.Text);
                if (student != null)
                {
                    var confirm = MessageBox.Show("Bạn có chắc chắn muốn xóa sinh viên này?", "Xác nhận xóa", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (confirm == DialogResult.Yes)
                    {
                        context.Students.Remove(student);
                        context.SaveChanges();

                        BindGrid(context.Students.ToList()); // Load lại danh sách
                        ResetForm(); // Reset form về giá trị ban đầu

                        MessageBox.Show("Xóa sinh viên thành công!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Information);
                    }
                }
                else
                {
                    MessageBox.Show("Không tìm thấy MSSV cần xóa!", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Lỗi khi xóa dữ liệu: {ex.Message}", "Thông báo", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void dgvStudent_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.RowIndex >= 0)
            {
                DataGridViewRow selectedRow = dgvStudent.Rows[e.RowIndex];
                txtMaSoSV.Text = selectedRow.Cells[0].Value.ToString();
                txtHoTen.Text = selectedRow.Cells[1].Value.ToString();
                cmbKhoa.SelectedItem = selectedRow.Cells[2].Value.ToString();
                txtDiemTB.Text = selectedRow.Cells[3].Value.ToString();
            }
        }

        private void btnThoat_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult = MessageBox.Show(
     "Bạn có chắc chắn muốn thoát không?",
     "Xác nhận thoát",
     MessageBoxButtons.YesNo,
     MessageBoxIcon.Question
 );

            if (dialogResult == DialogResult.Yes)
            {
                Application.Exit(); // Thoát ứng dụng
            }
        }
    }
}
